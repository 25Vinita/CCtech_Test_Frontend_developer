//Allow users to enter a city name in an input field and click a button to fetch weather data.

